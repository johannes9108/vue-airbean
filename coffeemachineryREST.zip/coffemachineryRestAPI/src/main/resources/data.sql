insert into coffee (title,description,price) values
('Bryggkaffe','Bryggd på månadens bönor', 39),
('Caffé Doppio','Bryggd på månandens bönor', 49), 
('Cappuccino','Bryggd på månadens bönor', 49), 
('Latte Macchiato','Bryggd på månadens bönor', 49), 
('Kaffe Latte','Bryggd på månadens bönor', 54),
('Cortado','Bryggd på månadens bönor', 39);

insert into customer(name, email, password) values
('Johannes','Johannes@mail.com','1234');